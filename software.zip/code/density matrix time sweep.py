# -*- coding: utf-8 -*-

#This code allows to simulate Fidelity and Concurrence of a perfectly compensated entangled state (dW1=dW2=0) when a temporal mismatch is present. Assuming perfect compensation allows to remove the need to generate and average random density matrixes
"""Copyright (C) <2021>  <Simone Varo>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
    Author can be contacted at: simone.varo@tyndall.ie
    """

import numpy as np
from math import sqrt,pi
from cmath import exp
from scipy.constants import hbar
from scipy.constants import e
import scipy.linalg as linalg


class DensityMatrix:
    def __init__(self):
        self.matrix=(1/2)*np.array([[1.0+0j,0.0+0j,0.0+0j,0.0+0j],[0.0+0j,0.0+0j,0.0+0j,0.0+0j],[0.0+0j,0.0+0j,0.0+0j,0.0+0j],[0.0+0j,0.0+0j,0.0+0j,1.0+0j]])
        self.iterationNumber=0
        self.converged=False
        self.previousStepmatrix=np.array([[1.0+0j,0.0+0j,0.0+0j,0.0+0j],[0.0+0j,0.0+0j,0.0+0j,0.0+0j],[0.0+0j,0.0+0j,0.0+0j,0.0+0j],[0.0+0j,0.0+0j,0.0+0j,1.0+0j]])
        
    def convergencecheck(self,convergence):
        if abs((self.matrix[0,3]-self.previousStepmatrix[0,3]))/abs(self.matrix[0,3])<convergence:
            self.converged=True
            
    def fidelity_1(self):                                                            #fidelity to (1/sqrt(2))(|00>+|11>)
        bell=(1/2)*np.array([[1,0,0,1],[0,0,0,0],[0,0,0,0],[1,0,0,1]])
        bell=linalg.sqrtm(bell)
        fidelity=(np.trace(linalg.sqrtm(np.matmul(np.matmul(bell,self.matrix),bell))))**2
        return (abs(fidelity))
    
    def fidelity_2(self):                                                            #fidelity to (1/sqrt(2))(|00>-|11>)
        bell=(1/2)*np.array([[1,0,0,-1],[0,0,0,0],[0,0,0,0],[-1,0,0,1]])
        bell=linalg.sqrtm(bell)
        fidelity=(np.trace(linalg.sqrtm(np.matmul(np.matmul(bell,self.matrix),bell))))**2
        return (abs(fidelity))
    
    
    def concurrence(self):
        S=[[0,0,0,-1],[0,0,1,0],[0,1,0,0],[-1,0,0,0]]
        array=[self.matrix,S,np.transpose(self.matrix),S]
        R=np.linalg.multi_dot(array)
        w,v=np.linalg.eig(R)
        w=np.round(w,roundingTolerance)
        w=np.sort(w)[::-1]
        for item in np.iscomplex(w):
            if item==True:
                raise NameError("Complex Eigenvalues! Check rounding accuracy") 
        return(max(0,sqrt(w[0])-sqrt(w[1])-sqrt(w[2])-sqrt(w[3])))
        

            
        

def newIteration(DensityMatrix,lifetimeXX,lifetimeX,FSS,deltaT):
    
    phaseTerm1=(1/2)*exp(-1j*(FSS/hbar)*deltaT)
    phaseTerm2=(1/2)*exp(1j*(FSS/hbar)*deltaT)
    DensityMatrix.matrix[0,3]=((DensityMatrix.matrix[0,3]*DensityMatrix.iterationNumber)+phaseTerm1)/(DensityMatrix.iterationNumber+1)
    DensityMatrix.matrix[3,0]=((DensityMatrix.matrix[3,0]*DensityMatrix.iterationNumber)+phaseTerm2)/(DensityMatrix.iterationNumber+1)
    DensityMatrix.iterationNumber+=1
    
lifetimeX=pow(10,-9)      #exciton lifetime (1 ns)
lifetimeXX=lifetimeX/2    #biexciton lifetime assumed to be 1/2 of that of the exciton
FSS=3*pow(10,-6)*e        #FSS in eV
convergence=pow(10,-6)    #relative variation of the density matrix's extradiagonal elements that ensures covergence
roundingTolerance=10      #allows to discard small imaginary components in the eigenvalues arising due to finite machine precision, or to raise an error otherwise
discretization=20         #discretization of simulation parameters deltaW1 and deltaW2



index=0
dataStorage=np.zeros((discretization,4))

for deltaT in np.linspace(-pow(10,-9),pow(10,-9),discretization):
    mymatrix=DensityMatrix()
    newIteration(mymatrix,lifetimeXX,lifetimeX,FSS,deltaT)
    dataStorage[index][0]=deltaT
    dataStorage[index][1]=mymatrix.fidelity_1()
    dataStorage[index][2]=mymatrix.fidelity_2()
    dataStorage[index][3]=mymatrix.concurrence()
    index+=1
    print("Completed: ",index,"of ", discretization)
        
print("simulation completed")
#saving data on file
np.savetxt('result.csv',dataStorage,delimiter=';')